<?php

namespace app\wechat\controller;

use think\Controller;
use think\Request;
use \wechat\sdk\Jsapi;

class Test extends Controller
{
    /**
     * 获取前端JS 配置信息
     * JS-SDK的页面必须先注入配置信息
     * @return \think\Response
     */
    public function index()
    {
        $jsapi = new Jsapi();
        $jsConfig = $jsapi->getSignPackage();
        if(isset($jsConfig['code']) && $jsConfig['code'] == 0){
            return json(['code'=>0,'msg'=>$jsConfig['msg']]);
        }
        return json($jsConfig);
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request  $request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    /**
     * 显示指定的资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function read($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request  $request
     * @param  int  $id
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * 删除指定资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function delete($id)
    {
        //
    }
}
