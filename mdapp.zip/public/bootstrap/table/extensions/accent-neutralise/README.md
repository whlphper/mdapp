# Table Accent Neutralise

Use Plugin: [bootstrap-table-accent-neutralise](https://github.com/wenzhixin/bootstrap-table/tree/master/src/extensions/accent-neutralise)

## Usage

```html
<script src="extensions/multiple-search/bootstrap-table-accent-neutralise.js"></script>
```

## Options

### searchAccentNeutralise

* type: Boolean
* description: Set to true if you want to use accent neutralise feature.
* default: `false`
