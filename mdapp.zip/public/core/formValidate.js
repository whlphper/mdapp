/*
* 学习记录
* 整理下validate验证方法
* required(regex)
* required(function)
* remote(url)
* minlength
* maxlength
* min
* max
* email
* range(1-10)
* url
* date
* number
* digits
* creditcard
* accept(.png)
* equalTo()
*
*/