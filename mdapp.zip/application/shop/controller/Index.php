<?php
namespace app\shop\controller;
use app\common\controller\Base;
use think\Request;
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/17 0017
 * Time: 9:38
 */
class Index extends Base{


}