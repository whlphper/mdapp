<?php
/**
 * Created by whlphper.
 * User: Administrator
 * Date: 2018/4/23 0023
 * Time: 14:19
 * Comment:
 */
namespace app\common\model;
use app\common\model\Base;
class SearchHistory extends Base{


}