<?php
/**
 * Created by whlphper.
 * User: Administrator
 * Date: 2018/4/23 0023
 * Time: 9:33
 * Comment:
 */
namespace app\common\model;
use app\common\model\Base;
class Catalog extends Base{


}