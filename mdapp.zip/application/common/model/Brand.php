<?php
/**
 * Created by whlphper.
 * User: Administrator
 * Date: 2018/4/17 0017
 * Time: 11:37
 * Comment:
 */
namespace app\common\model;
use app\common\model\Base;
class Brand extends Base{


}