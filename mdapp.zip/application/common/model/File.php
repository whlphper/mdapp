<?php
/**
 * Created by whlphper.
 * User: Administrator
 * Date: 2018/4/19 0019
 * Time: 9:57
 * Comment:
 */
namespace app\common\model;
use think\Model;
use app\common\model\Base;
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/18 0018
 * Time: 15:12
 */
class File extends Base
{

}