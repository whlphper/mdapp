<?php
namespace app\common\model;
use app\common\model\Base;
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/26 0026
 * Time: 18:59
 */
class Dict extends Base{

}