<?php
/**
 * Created by whlphper.
 * User: Administrator
 * Date: 2018/4/20 0020
 * Time: 13:12
 * Comment:
 */
namespace app\common\model;
use app\common\model\Base;
class Address extends Base{


}