<?php
namespace app\common\model;
use think\Model;
use app\common\model\Base;
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/18 0018
 * Time: 15:12
 */
class User extends Base
{

}