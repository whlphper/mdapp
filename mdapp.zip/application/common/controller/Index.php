<?php
/**
 * Created by whlphper.
 * User: Administrator
 * Date: 2018/4/17 0017
 * Time: 16:40
 * Comment:
 */
namespace app\pcshop\controller;
use app\pcshop\controller\Base;
use think\Request;
use think\Db;

class Index extends Base
{

}